/* BID Vision: read-only inventory, no video stream or MCU commands. */
(function(){'use strict';
const $=id=>document.getElementById(id),has=n=>!!window.BID&&typeof BID[n]==='function';
const panel=document.createElement('div');panel.id='bidVisionPanel';panel.hidden=true;panel.setAttribute('role','dialog');panel.setAttribute('aria-label','BID Vision');panel.style.cssText='position:absolute;inset:0;z-index:31;background:#080407f5;padding:24px 65px;color:#ffe6bd;overflow:auto';
panel.innerHTML='<section style="border:2px solid #c5a06a;border-radius:22px;padding:22px;background:linear-gradient(135deg,#210c17,#451326,#190c12)"><button id="bidVisionClose" class="close">Înapoi ✕</button><h1 style="font-size:36px">BID Vision · Camere și parcare</h1><div id="bidVisionStatus" role="status" style="font-size:20px;line-height:1.5;white-space:pre-line"></div><div class="row" style="margin:18px 0"><button id="bidVisionOem">Funcții originale QF001</button><button id="bidVisionCar">Setări auto OEM</button><button id="bidVisionRefresh">Verifică disponibilitatea</button></div><p style="font-size:18px;line-height:1.4">Cameră marșarier: funcția originală rămâne responsabilă de comutarea la R. BID nu o comandă și nu o înlocuiește. Camera 360°, DVR și senzorii necesită hardware și compatibilitate verificate. Un pachet detectat nu confirmă un flux video sau date reale. Verifică meniurile numai cu mașina staționată.</p></section>';
$('stage').appendChild(panel);
function refresh(){let d=null;try{if(has('diagnostics'))d=JSON.parse(BID.diagnostics());}catch(_){}
const entries=d&&d.originalQf001Apps&&typeof d.originalQf001Apps==='object'?Object.entries(d.originalQf001Apps).filter(([k,v])=>v&&v.launchableVisible===true).map(([k,v])=>({label:k,pkg:typeof v.package==='string'?v.package:''})):[];
const candidates=d&&Array.isArray(d.candidateCarApps)?d.candidateCarApps.filter(v=>v&&typeof v==='object').map(v=>({label:typeof v.label==='string'?v.label:'',pkg:typeof v.package==='string'?v.package:''})):[];
const all=entries.concat(candidates);const find=re=>[...new Set(all.filter(v=>re.test(v.label+' '+v.pkg)).map(v=>v.label||v.pkg))].slice(0,8);
const report=(label,re)=>{const matches=find(re);return label+': '+(matches.length?'aplicații candidate – '+matches.join(', ')+'; hardware neconfirmat':'nedetectat / vizibilitate necunoscută');};
$('bidVisionStatus').textContent=[report('Cameră 360°',/360|surround|around.?view|\bavm\b/i),report('DVR',/dvr|dash.?cam|recorder/i),report('Cameră marșarier',/rear.?cam|reverse|back.?cam/i),report('Parcare / senzori',/parking|park.?assist|\bpdc\b/i),'CAN-BUS: '+(d&&d.canbusPackageVisible===true?'pachet vizibil; date senzori neconfirmate':'neconfirmat'),!d?'Inventarul nativ este indisponibil.':'Inventar orientativ; nicio comandă către camere sau senzori.'].join('\n');
$('bidVisionOem').disabled=!has('showOemFunctions');$('bidVisionCar').disabled=!has('open');}
function close(){panel.hidden=true;}const previous=window.closeAll;window.closeAll=function(){close();return previous.apply(this,arguments);};
window.bidVisionOpen=function(){window.closeAll();panel.hidden=false;refresh();};$('bidVisionClose').onclick=()=>{close();window.openMusicMenu();};$('bidVisionRefresh').onclick=refresh;
function invoke(n,arg){if(!has(n))return;try{if(arg===undefined)BID[n]();else BID[n](arg);close();}catch(_){$('bidVisionStatus').textContent='Comanda OEM nu a putut fi transmisă.';}}
$('bidVisionOem').onclick=()=>invoke('showOemFunctions');$('bidVisionCar').onclick=()=>invoke('open','car');
})();
