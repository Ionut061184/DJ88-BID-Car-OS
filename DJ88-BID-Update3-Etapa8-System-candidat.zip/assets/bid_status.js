/* BID MASTER: dynamic, read-only state; never simulate a signal. */
(function(){
'use strict';
const $=id=>document.getElementById(id);
const weather=$('bidWeatherText'),bt=$('bidBtText'),cell=$('bidCellText'),wifi=$('bidWifiText'),battery=$('bidBatteryText'),voltage=$('bidVoltageText');
if(!weather||!bt||!cell||!wifi||!battery||!voltage)return;
const gold='#f6d69c',white='#f2efeb',muted='#747076',dim='#39363b';
const valid=(n,max)=>Number.isInteger(n)&&n>=0&&n<=max;
const svg=(body,w=24,h=24)=>`<svg viewBox="0 0 ${w} ${h}" width="${w}" height="${h}" aria-hidden="true">${body}</svg>`;
function label(el,text){el.title=text;el.setAttribute('aria-label',text)}
function render(s){
 s=s||{};
 const b=s.bluetooth===false?dim:s.bluetooth===true?(s.bluetoothConnected===true?gold:s.bluetoothConnected===false?white:muted):muted;
 bt.innerHTML=svg(`<path d="M11 2 L18 8 L13 12 L18 16 L11 22 V2 M5 6 L17 18 M5 18 L17 6" fill="none" stroke="${b}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>`);
 label(bt,'Bluetooth: '+(s.bluetooth===false?'oprit':s.bluetooth===true?(s.bluetoothConnected===true?'conectat':s.bluetoothConnected===false?'pornit, neconectat':'pornit, conexiune necunoscută'):'indisponibil'));
 const level=s.wifi===true&&s.wifiConnected===true&&valid(s.wifiLevel,4)?s.wifiLevel:null;
 const wc=s.wifi===false?dim:s.wifi===true&&s.wifiConnected===false?white:muted;
 const arc=(i)=>level!==null?(level>=i?gold:dim):wc;
 const traffic=(v)=>s.wifi===true&&s.wifiConnected===true&&v===true?gold:dim;
 wifi.innerHTML=svg(`<g fill="none" stroke-width="1.8" stroke-linecap="round"><path d="M2 7 Q12 -1 22 7" stroke="${arc(4)}"/><path d="M5 10 Q12 4 19 10" stroke="${arc(3)}"/><path d="M9 13 Q12 10 15 13" stroke="${arc(2)}"/></g><circle cx="12" cy="16" r="1.5" fill="${arc(1)}"/><path d="M7 19v4m-2-2 2 2 2-2" stroke="${traffic(s.wifiRx)}" fill="none" stroke-width="1.4"/><path d="M17 23v-4m-2 2 2-2 2 2" stroke="${traffic(s.wifiTx)}" fill="none" stroke-width="1.4"/>`);
 label(wifi,'Wi-Fi: '+(s.wifi===false?'oprit':s.wifi===true?(s.wifiConnected===true?'conectat'+(level===null?', nivel necunoscut':`, nivel ${level}/4`):s.wifiConnected===false?'pornit, neconectat':'pornit, conexiune necunoscută'):'indisponibil')+((s.wifiRx===true||s.wifiTx===true)?', trafic activ':s.wifiRx===false&&s.wifiTx===false?', trafic inactiv':', trafic neconfirmat'));
 const cl=s.simPresent===true&&valid(s.cellLevel,4)?s.cellLevel:null;
 const g=s.simPresent===true&&['2G','3G','4G','4G+','5G','5G+','6G'].includes(s.networkGeneration)?s.networkGeneration:'';
 const bars=[0,1,2,3].map(i=>`<rect x="${3+i*5}" y="${22-(i+1)*3}" width="3" height="${(i+1)*3}" rx=".5" stroke="${cl===null?muted:gold}" stroke-width=".7" fill="${cl!==null&&cl>i?gold:'none'}"/>`).join('');
 cell.innerHTML=svg(`<text x="13" y="8" text-anchor="middle" font-family="Arial" font-size="9" fill="${g?gold:muted}">${g|| (s.simPresent===false?'×':'—')}</text>${bars}`,26,24);
 label(cell,s.simPresent===false?'SIM absent':s.simPresent===true?'SIM: '+(g||'rețea necunoscută')+', '+(cl===null?'semnal necunoscut':`nivel ${cl}/4`):'SIM: stare necunoscută');
}
function snapshot(name){try{return window.BID&&typeof BID[name]==='function'?JSON.parse(BID[name]()):{};}catch(_){return {};}}
function refresh(){
 const v=snapshot('vehicleVoltageSnapshot');voltage.textContent=v.available===true&&typeof v.volts==='number'&&Number.isFinite(v.volts)&&v.volts>=9&&v.volts<=16.5?v.volts.toFixed(1)+' V':'— V';
 const b=snapshot('batterySnapshot');battery.textContent=valid(b.percent,100)?'▣ '+b.percent+'%':'—%';
 render(snapshot('connectivitySnapshot'));
}
weather.textContent='—° GPS';
const oldWeather=window.updateWeather;
function renderWeather(city,temp,description){
 if(typeof oldWeather==='function')oldWeather(city,temp,description);
 const t=typeof temp==='number'&&Number.isFinite(temp)?Math.round(temp)+'°':'—°';
 weather.textContent=t+(city?' · '+String(city):'');label(weather,description||'Vreme');
}
window.updateWeather=renderWeather;
window.updateGpsWeather=function(data){
 const d=data||{};renderWeather(d.city||'GPS',d.temperature,d.note||'');
 if(d.fresh!==true)weather.textContent='* '+weather.textContent;
 label(weather,(d.city||'GPS')+' · '+(d.note||'')+(d.fresh===true?'':' · neactualizat'));
};
refresh();setInterval(refresh,3000);document.addEventListener('visibilitychange',()=>{if(!document.hidden)refresh()});
})();
