/* Update 3 candidate: read-only capability dashboard; original OEM grid preserved. */
(function(){'use strict';
 const $=id=>document.getElementById(id), has=n=>!!window.BID&&typeof BID[n]==='function';
 const read=n=>{try{return has(n)?JSON.parse(BID[n]()):null}catch(_){return null}};
 const panel=document.createElement('div');panel.id='bidSmartPanel';panel.setAttribute('role','dialog');panel.setAttribute('aria-label','BID Smart Vehicle');panel.hidden=true;
 panel.style.cssText='position:absolute;inset:0;z-index:30;background:#080407e8;padding:28px 65px;overflow:auto;color:#f6dfb8';
 panel.innerHTML='<section style="border:2px solid #c5a06a;border-radius:22px;padding:20px;background:linear-gradient(135deg,#210c17,#451326,#190c12)"><button class="close" id="bidSmartClose">Închide ✕</button><h1 style="font-size:34px">BID Smart Vehicle</h1><div class="row" id="bidSmartActions"></div><div id="bidSmartBattery" style="margin:18px 0;font-size:24px"></div><div id="bidSmartInfo" style="font-size:19px;line-height:1.5;white-space:pre-line"></div></section>';
 $('stage').appendChild(panel);
 const close=()=>{panel.hidden=true}; $('bidSmartClose').onclick=close;
 const original=window.openMusicMenu, closeAllOriginal=window.closeAll;
 window.closeAll=function(){close();return closeAllOriginal.apply(this,arguments)};
 function action(label,available,fn){const b=document.createElement('button');b.textContent=label;b.disabled=!available;b.style.opacity=available?'1':'.48';b.onclick=()=>{close();fn()};$('bidSmartActions').appendChild(b)}
 function refresh(){if(panel.hidden)return;
  const v=read('vehicleVoltageSnapshot'),b=read('batterySnapshot'),d=read('diagnostics');
  const volts=v&&v.available===true&&Number.isFinite(v.volts)&&v.volts>=9&&v.volts<=16.5?v.volts:null;
  const percent=b&&Number.isInteger(b.percent)&&b.percent>=0&&b.percent<=100?b.percent:null;
  $('bidSmartBattery').textContent='BID Battery · Auto: '+(volts===null?'indisponibil':volts.toFixed(1)+' V')+' · Android: '+(percent===null?'indisponibil':percent+'%');
  const apps=d&&d.originalQf001Apps&&typeof d.originalQf001Apps==='object'?Object.entries(d.originalQf001Apps).filter(([k,x])=>x&&x.launchableVisible===true).map(([k])=>k):[];
  $('bidSmartInfo').textContent='Aplicații OEM detectate: '+(apps.length?apps.join(', '):'nedetectate / vizibilitate necunoscută')+'\nCAN-BUS: '+(d&&d.canbusPackageVisible===true?'pachet detectat; datele vehiculului nu sunt validate':'neconfirmat')+'\nViteză GPS, consum, climatizare, TPMS, camere și OBD2: necesită verificarea sursei native sau hardware. Nu sunt simulate.';
 }
 window.openMusicMenu=function(){closeAll();$('bidSmartActions').textContent='';
  action('Funcții originale QF001',true,original);
  action('BID Performance · GPS',typeof window.bidTripOpen==='function',()=>bidTripOpen());
  action('BID Battery · 12 V',typeof window.bidBatteryOpen==='function',()=>bidBatteryOpen());
  action('Diagnostic BID',typeof window.bidDiagOpen==='function',()=>bidDiagOpen());
  action('BID Vision · Camere',typeof window.bidVisionOpen==='function',()=>bidVisionOpen());
  action('BID Sound · DSP',typeof window.bidSoundOpen==='function',()=>bidSoundOpen());
  action('Aplicații auto',has('showCarApps'),()=>autoApps());
  action('Luminozitate BID',typeof window.bidDisplayOpen==='function',()=>bidDisplayOpen(true));
  action('Teme BID',typeof window.bidThemesOpen==='function',()=>bidThemesOpen());
  action('BID System',typeof window.bidSystemOpen==='function',()=>bidSystemOpen());
  panel.hidden=false;refresh();
 };setInterval(refresh,3000);
})();
