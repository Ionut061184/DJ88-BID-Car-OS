/* BID Diagnostics: read-only local inventory, never an ECU scan. */
(function(){'use strict';
const $=id=>document.getElementById(id),has=(obj,n)=>!!obj&&typeof obj[n]==='function';
function read(n){try{const d=has(window.BID,n)?JSON.parse(BID[n]()):null;return d&&typeof d==='object'&&!Array.isArray(d)?d:null;}catch(_){return null;}}
const panel=document.createElement('div');panel.id='bidDiagPanel';panel.hidden=true;panel.setAttribute('role','dialog');panel.setAttribute('aria-label','BID Diagnostics');panel.style.cssText='position:absolute;inset:0;z-index:31;background:#080407f5;padding:24px 65px;color:#ffe6bd;overflow:auto';
panel.innerHTML='<section style="border:2px solid #c5a06a;border-radius:22px;padding:22px;background:linear-gradient(135deg,#210c17,#451326,#190c12)"><button id="bidDiagClose" class="close">Înapoi ✕</button><h1 style="font-size:36px">BID Diagnostics · Inventar local</h1><div id="bidDiagStatus" role="status" style="font-size:20px;line-height:1.45;white-space:pre-line;overflow-wrap:anywhere"></div><div class="row" style="margin:18px 0"><button id="bidDiagRefresh">Reverifică</button><button id="bidDiagOriginal">Raport OEM detaliat</button><button id="bidDiagOem">Funcții originale QF001</button></div><p style="font-size:18px">Inventar informativ. Nu citește erori ECU, nu șterge coduri, nu împerechează adaptoare, nu scrie în CAN/MCU. Verifică numai cu mașina staționată.</p></section>';
$('stage').appendChild(panel);
const tri=v=>v===true?'raportat disponibil':v===false?'raportat indisponibil':'necunoscut';
const str=v=>typeof v==='string'&&v.trim()?v.trim().slice(0,100):'necunoscut';
function refresh(){const d=read('diagnostics'),v=read('vehicleVoltageSnapshot');
const valid=v&&v.available===true&&typeof v.volts==='number'&&Number.isFinite(v.volts)&&v.volts>=9&&v.volts<=16.5;
let lines=['Inventar nativ: '+(d?'primit':'indisponibil'), 'Dispozitiv: '+str(d?.deviceManufacturer)+' / '+str(d?.deviceModel)+' · Android '+str(d?.androidRelease), 'Tensiune auto: '+(valid?v.volts.toFixed(1)+' V · raportată de sursă; calibrare/vechime neconfirmate':'indisponibilă')];
const comps=Array.isArray(d?.canbusExportedComponents)?d.canbusExportedComponents.filter(x=>x&&typeof x.name==='string'):null;
lines.push('CAN-BUS: pachet '+tri(d?.canbusPackageVisible)+'; lansator '+tri(d?.canbusHasPublicLauncher)+(comps?'; componente exportate în inventar: '+comps.length:'; componente necunoscute')+'. Date ECU, climatizare și senzori neconfirmate.');
const apps=d?.originalQf001Apps&&typeof d.originalQf001Apps==='object'&&!Array.isArray(d.originalQf001Apps)?Object.entries(d.originalQf001Apps):[];
const candidates=Array.isArray(d?.candidateCarApps)?d.candidateCarApps:[];
const seen=apps.filter(([,x])=>x&&x.launchableVisible===true).map(([k,x])=>({label:k,package:x.package}));
const names=seen.map(x=>str(x.label)).slice(0,12);
lines.push('Aplicații OEM vizibile și lansabile conform inventarului: '+(names.length?names.join(', '):'niciuna raportată / inventar incomplet'));
const obd=[...new Set(seen.concat(candidates).filter(x=>x&&/\bobd\s*[-_]?\s*(?:ii|2)?\b|elm\s*327|car.?scanner|torque|vcds/i.test(String(x.label||'')+' '+String(x.package||''))).map(x=>str(x.label||x.package)))].slice(0,8);
lines.push('OBD2: '+(obd.length?'aplicații candidate: '+obd.join(', '):'nicio aplicație candidată detectată')+'; adaptor, conexiune și protocol ECU neconfirmate.');
lines.push('GPS Performance: '+(has(window.BIDTrip,'snapshot')&&has(window.BIDTrip,'start')&&has(window.BIDTrip,'stop')?'bridge prezent; fix GPS neconfirmat':'bridge nativ absent/incomplet'));
const bindings=d?.assignedAutoShortcuts&&typeof d.assignedAutoShortcuts==='object'?d.assignedAutoShortcuts:{};
lines.push('Asocieri OEM: '+['radio','dsp','btcar'].map(k=>k+' – '+tri(bindings[k]?.available)).join('; '));
$('bidDiagStatus').textContent=lines.join('\n');$('bidDiagOriginal').disabled=!d||typeof window.diagnostic!=='function';$('bidDiagOem').disabled=!has(window.BID,'showOemFunctions');}
function close(){panel.hidden=true;}const previous=window.closeAll;window.closeAll=function(){close();return previous.apply(this,arguments);};
window.bidDiagOpen=function(){window.closeAll();panel.hidden=false;refresh();};$('bidDiagClose').onclick=()=>{close();window.openMusicMenu();};$('bidDiagRefresh').onclick=refresh;
$('bidDiagOriginal').onclick=()=>{close();window.diagnostic();};$('bidDiagOem').onclick=()=>{try{if(has(window.BID,'showOemFunctions')){BID.showOemFunctions();close();}}catch(_){$('bidDiagStatus').textContent='Meniul OEM nu a putut fi deschis.';}};
})();
