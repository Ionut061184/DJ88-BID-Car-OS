from pathlib import Path
import json
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parent
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1280,'height':720})
    import base64
    assets=root/'assets'
    html=(assets/'index.html').read_text()
    css=(assets/'bid_status.css').read_text()
    html=html.replace('<link rel="stylesheet" href="bid_status.css">','<style>'+css+'</style>')
    for n in ('bid_approved.png','bid_fullbleed.png'):
        html=html.replace(n,'data:image/png;base64,'+base64.b64encode((assets/n).read_bytes()).decode())
    setup='Object.defineProperty(window,"localStorage",{value:{data:{},setItem(k,v){this.data[k]=v},getItem(k){return this.data[k]??null}}});window.testState={};window.testDisplay={};window.appliedModes=[];window.BID={displaySnapshot:()=>JSON.stringify(window.testDisplay),setDisplayMode:m=>window.appliedModes.push(m),connectivitySnapshot:()=>JSON.stringify(window.testState),batterySnapshot:()=>JSON.stringify({percent:100}),vehicleVoltageSnapshot:()=>JSON.stringify({available:true,volts:12.2})};'
    html=html.replace('</head>','<script>'+setup+'</script></head>')
    for n in ('bid_runtime.js','bid_status.js','bid_adaptive.js','bid_smart.js','bid_trip.js','bid_battery.js','bid_sound.js','bid_vision.js','bid_diagnostics.js','bid_themes.js','bid_system.js'):
        html=html.replace('<script src="'+n+'"></script>','<script>'+(assets/n).read_text()+'</script>')
    page.clock.install()
    page.set_content(html)
    def resize(w,h):
        page.set_viewport_size({"width":w,"height":h})
        page.evaluate("() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)))")
    def status(state):
        page.evaluate('(s)=>{window.testState=s; document.dispatchEvent(new Event("visibilitychange"));}',state)
    def aria(id):return page.locator('#'+id).get_attribute('aria-label')
    status({'bluetooth':False,'wifi':False,'simPresent':False})
    assert aria('bidBtText')=='Bluetooth: oprit'
    assert aria('bidWifiText').startswith('Wi-Fi: oprit')
    assert aria('bidCellText')=='SIM absent'
    status({'bluetooth':True,'bluetoothConnected':False,'wifi':True,'wifiConnected':False,'simPresent':True,'cellLevel':0,'networkGeneration':'2G'})
    assert 'neconectat' in aria('bidBtText') and 'neconectat' in aria('bidWifiText')
    assert '2G' in aria('bidCellText') and '0/4' in aria('bidCellText')
    status({'bluetooth':True,'bluetoothConnected':True,'wifi':True,'wifiConnected':True,'wifiLevel':2,'wifiRx':True,'wifiTx':False,'simPresent':True,'cellLevel':3,'networkGeneration':'4G+'})
    assert aria('bidBtText')=='Bluetooth: conectat'
    assert '2/4' in aria('bidWifiText') and 'trafic activ' in aria('bidWifiText')
    assert '4G+' in aria('bidCellText') and '3/4' in aria('bidCellText')
    assert page.locator('#bidCellText rect[fill="#f6d69c"]').count()==3
    assert page.locator('#bidVoltageText').inner_text()=='12.2 V'
    assert '100%' in page.locator('#bidBatteryText').inner_text()
    page.evaluate('window.updateGpsWeather({city:"Robăneștii de Sus – localitate cu denumire lungă",temperature:6,code:3,fresh:true,note:"Vreme după GPS"})')
    assert page.locator('#bidWeatherText').inner_text().startswith('6° · Robăneștii')
    for w,h in [(1280,720),(1856,821)]:
        resize(w,h)
        band=page.locator('#bidStatusLive').bounding_box()
        assert band and band['width']>0
        for id in ['bidWeatherText','bidBtText','bidCellText','bidWifiText','bidBatteryText','bidVoltageText']:
            b=page.locator('#'+id).bounding_box()
            assert b['x']>=band['x']-0.1 and b['x']+b['width']<=band['x']+band['width']+0.1,(w,id,b,band)
    resize(1280,720)
    page.evaluate('window.updateGpsWeather({city:"Robăneștii de Sus",temperature:6,code:3,fresh:false,note:"Date meteo neactualizate"})')
    assert page.locator('#bidWeatherText').inner_text().startswith('* 6°')
    status({})
    assert 'indisponibil' in aria('bidBtText') and 'necunoscută' in aria('bidCellText')
    status({'simPresent':True,'networkGeneration':'6G','cellLevel':4,'wifi':True,'wifiConnected':True,'wifiLevel':4,'bluetooth':True,'bluetoothConnected':True})
    assert '6G' in aria('bidCellText') # renderer only, not hardware support
    # Weather conditions and day/night are driven only by the provider.
    for code,day,name in [(0,True,'Senin'),(0,False,'Senin'),(2,True,'Parțial noros'),(3,True,'Noros'),(45,True,'Ceață'),(61,True,'Ploaie'),(73,True,'Ninsoare'),(95,True,'Furtună')]:
        page.evaluate('(d)=>window.updateGpsWeather(d)',{'city':'Robăneștii de Sus','temperature':6,'code':code,'isDay':day,'fresh':True})
        assert aria('bidWeatherIcon')==name
        assert page.locator('#bidWeatherIcon img').count()==1
        assert page.locator('#bidWeatherIcon img').evaluate('(img)=>img.src.startsWith("data:image/png;base64,")')
    page.evaluate('window.updateGpsWeather({code:0,isDay:false,fresh:false})')
    assert 'neactualizat' in aria('bidWeatherIcon')
    def display(lux,expected):
        page.evaluate('(lux)=>{window.testDisplay={lux};window.bidDisplayMode("auto")}',lux)
        assert page.evaluate('window.appliedModes.at(-1)')==expected
    display(14000,'sun');display(9000,'sun');display(400,'day');display(12,'night');display(35,'night');display(90,'day');display(None,'system')
    page.evaluate('window.updateGpsWeather({code:0,isDay:false,fresh:true})')
    assert page.evaluate('window.appliedModes.at(-1)')=='night'
    page.evaluate('window.updateGpsWeather({code:0,isDay:true,fresh:true})')
    assert page.evaluate('window.appliedModes.at(-1)')=='day'
    page.evaluate('window.bidDisplayOpen(true)')
    page.locator('[data-bid-display=sun]').click()
    assert page.evaluate('window.appliedModes.at(-1)')=='sun'
    assert page.evaluate('localStorage.getItem("bid_display_mode")')=='sun'
    page.evaluate('closeAll()')
    assert not page.locator('#bidDisplayPanel').is_visible()
    for w,h in [(1280,720),(1856,821)]:
        resize(w,h)
        icon=page.locator('#bidWeatherIcon').bounding_box();band=page.locator('#bidStatusLive').bounding_box()
        assert icon['x']+icon['width']<=band['x']+0.1
        assert icon["y"]>=band["y"]-0.1 and icon["y"]+icon["height"]<=band["y"]+band["height"]+0.1,(icon,band)
    print('PASS: 7 original scenarios + 8 weather states, stale state, 7 sensor transitions, 2 GPS daylight fallbacks, display setting persistence and two viewport bounds')
    page.evaluate('window.BID.showFunctionsGrid=()=>window.oemOpened=true;window.openMusicMenu()')
    assert page.locator('#bidSmartPanel').is_visible()
    assert '12.2 V' in page.locator('#bidSmartBattery').inner_text()
    page.get_by_role('button',name='Funcții originale QF001',exact=True).last.click()
    assert page.evaluate('window.oemOpened===true')
    assert not page.locator('#bidSmartPanel').is_visible()
    page.evaluate('window.BID.vehicleVoltageSnapshot=()=>JSON.stringify({available:false,volts:14});window.openMusicMenu()')
    assert 'Auto: indisponibil' in page.locator('#bidSmartBattery').inner_text()
    page.evaluate('closeAll()')
    assert not page.locator('#bidSmartPanel').is_visible()
    print('PASS: Smart Vehicle opens, real voltage only, native OEM access retained, closeAll works')
    page.evaluate('window.openMusicMenu()')
    page.get_by_role('button',name='BID Performance · GPS',exact=True).click()
    assert 'neintegrat' in page.locator('#bidGpsState').inner_text()
    assert page.locator('#bidTripSpeed').inner_text()=='—'
    assert page.locator('#bidTripStart').is_disabled()
    page.evaluate('window.BIDTrip={start:()=>{},stop:()=>{window.gpsStopped=true},snapshot:()=>JSON.stringify(window.fix)};window.fix={available:true,provider:"gps",ageMs:100,fixId:1000,accuracy:5,lat:44,lon:23,speedMps:10,bearing:90,altitude:100};window.bidTripOpen()')
    assert page.locator('#bidTripSpeed').inner_text()=='36 km/h'
    assert page.locator('#bidTripBearing').inner_text()=='90° E'
    assert page.locator('#bidTripAltitude').inner_text()=='100 m'
    page.locator('#bidTripStart').click()
    page.evaluate('window.fix.fixId=2000')
    page.wait_for_timeout(1100)
    page.evaluate('window.fix.fixId=3000;window.fix.lat=44.0001')
    page.wait_for_timeout(1100)
    assert page.locator('#bidTripDistance').inner_text()=='0.01 km'
    page.evaluate('window.fix.ageMs=6000')
    page.wait_for_timeout(1100)
    assert page.locator('#bidTripSpeed').inner_text()=='—'
    page.locator('#bidTripClose').click()
    assert page.evaluate('window.gpsStopped===true')
    assert page.locator('#bidSmartPanel').is_visible()
    print('PASS: GPS missing bridge, valid fix, direction, altitude, trip distance, stale fix and stop on close')
    page.evaluate('window.BID.vehicleVoltageSnapshot=()=>JSON.stringify({available:true,volts:13.8})')
    page.get_by_role('button',name='BID Battery · 12 V',exact=True).click()
    page.locator('#bidBatteryReset').click()
    assert page.locator('#bidBatteryNow').inner_text()=='13.8 V'
    page.evaluate('window.BID.vehicleVoltageSnapshot=()=>JSON.stringify({available:true,volts:11.8})')
    page.clock.run_for(20000)
    assert 'persistența' in page.locator('#bidBatteryState').inner_text()
    page.clock.run_for(21000)
    assert 'joasă persistentă' in page.locator('#bidBatteryState').inner_text()
    assert '11.8 V' in page.locator('#bidBatteryStats').inner_text()
    assert page.locator('#bidBatteryGraph polyline').count()>=1
    page.evaluate('window.BID.vehicleVoltageSnapshot=()=>JSON.stringify({available:false,volts:14})')
    page.clock.run_for(10000)
    assert page.locator('#bidBatteryNow').inner_text()=='— V'
    assert 'indisponibilă' in page.locator('#bidBatteryState').inner_text()
    page.evaluate('window.BID.vehicleVoltageSnapshot=()=>JSON.stringify({available:true,volts:15.2})')
    page.clock.run_for(31000)
    assert 'ridicată persistentă' in page.locator('#bidBatteryState').inner_text()
    page.evaluate('window.BID.vehicleVoltageSnapshot=()=>JSON.stringify({available:true,volts:99})')
    page.clock.run_for(10000)
    assert page.locator('#bidBatteryNow').inner_text()=='— V'
    page.locator('#bidBatteryReset').click()
    assert 'Fără istoric valid' in page.locator('#bidBatteryStats').inner_text()
    page.locator('#bidBatteryClose').click()
    assert page.locator('#bidSmartPanel').is_visible()
    assert not page.locator('#bidBatteryPanel').is_visible()
    print('PASS: BID Battery valid / invalid voltage, low and high persistence, graph, reset and menu return')
    page.get_by_role('button',name='BID Sound · DSP',exact=True).click()
    assert page.locator('#bidSoundDsp').is_disabled()
    assert 'nedetectat' in page.locator('#bidSoundStatus').inner_text()
    page.locator('[data-sound-profile=bass]').click()
    assert 'neaplicată' in page.locator('#bidSoundProfile').inner_text()
    assert page.evaluate('localStorage.getItem("bid_sound_profile")')=='bass'
    page.evaluate('window.BID.diagnostics=()=>JSON.stringify({assignedAutoShortcuts:{dsp:{available:true}}});window.soundCalls=[];window.BID.launchAuto=x=>soundCalls.push(x);window.BID.configureAuto=x=>soundCalls.push("config:"+x);window.BID.showOemFunctions=()=>soundCalls.push("oem");window.bidSoundOpen()')
    assert 'raportată disponibilă' in page.locator('#bidSoundStatus').inner_text()
    assert not page.locator('#bidSoundDsp').is_disabled()
    assert page.locator('[data-sound-profile=bass]').get_attribute('aria-pressed')=='true'
    assert page.evaluate('soundCalls.length')==0
    page.locator('#bidSoundDsp').click()
    assert page.evaluate('soundCalls.join(",")')=='dsp'
    assert not page.locator('#bidSoundPanel').is_visible()
    page.evaluate('bidSoundOpen()')
    page.locator('#bidSoundConfig').click()
    page.evaluate('bidSoundOpen()')
    page.locator('#bidSoundOem').click()
    assert page.evaluate('soundCalls.join(",")')=='dsp,config:dsp,oem'
    page.evaluate('bidSoundOpen()')
    page.locator('#bidSoundClose').click()
    assert page.locator('#bidSmartPanel').is_visible()
    print('PASS: BID Sound missing bridge, detection, manual profile preference, OEM DSP/config/menu dispatch, return')
    page.get_by_role('button',name='BID Vision · Camere',exact=True).click()
    assert 'nedetectat' in page.locator('#bidVisionStatus').inner_text()
    assert page.locator('#bidVisionCar').is_disabled()
    page.evaluate('window.visionCalls=[];window.BID.diagnostics=()=>JSON.stringify({originalQf001Apps:{"360 Camera":{launchableVisible:true,package:"example.avm"},"DVR":{launchableVisible:false}},candidateCarApps:[{label:"Dashcam",package:"example.dvr"},{label:"Parking assist",package:"example.parking"}],canbusPackageVisible:true});window.BID.open=x=>visionCalls.push(x);window.BID.showOemFunctions=()=>visionCalls.push("oem");window.bidVisionOpen()')
    v=page.locator('#bidVisionStatus').inner_text()
    assert '360 Camera' in v and 'Dashcam' in v and 'Parking assist' in v and 'hardware neconfirmat' in v
    assert 'date senzori neconfirmate' in v
    assert page.evaluate('visionCalls.length')==0
    page.locator('#bidVisionCar').click()
    assert page.evaluate('visionCalls.join(",")')=='car'
    page.evaluate('bidVisionOpen()')
    page.locator('#bidVisionOem').click()
    assert page.evaluate('visionCalls.join(",")')=='car,oem'
    page.evaluate('bidVisionOpen()')
    page.locator('#bidVisionClose').click()
    assert page.locator('#bidSmartPanel').is_visible()
    print('PASS: BID Vision inventory, unverified hardware, read-only detection, OEM dispatch and menu return')
    page.evaluate('delete window.BID.diagnostics;delete window.BIDTrip;window.openMusicMenu()')
    page.get_by_role('button',name='Diagnostic BID',exact=True).click()
    assert 'Inventar nativ: indisponibil' in page.locator('#bidDiagStatus').inner_text()
    assert 'bridge nativ absent' in page.locator('#bidDiagStatus').inner_text()
    assert page.locator('#bidDiagOriginal').is_disabled()
    page.evaluate('window.BID.diagnostics=()=>JSON.stringify({deviceManufacturer:"ROCO",deviceModel:"K706",androidRelease:"10",canbusPackageVisible:true,canbusHasPublicLauncher:false,canbusExportedComponents:[{name:"CANService"}],candidateCarApps:[{label:"Car Scanner",package:"test.obd2"}],originalQf001Apps:{Radio:{launchableVisible:true,package:"test.radio"},Hidden:{launchableVisible:false}},assignedAutoShortcuts:{dsp:{available:true}}});window.BID.vehicleVoltageSnapshot=()=>JSON.stringify({available:true,volts:13.1});window.BIDTrip={snapshot:()=>{},start:()=>{},stop:()=>{}};window.diagCalls=0;window.BID.showOemFunctions=()=>{window.diagCalls++};void 0')
    page.locator('#bidDiagRefresh').click()
    report=page.locator('#bidDiagStatus').inner_text()
    assert 'ROCO / K706' in report and '13.1 V' in report and 'Car Scanner' in report
    assert 'protocol ECU neconfirmate' in report and 'componente exportate în inventar: 1' in report
    assert 'Hidden' not in report and 'bridge prezent; fix GPS neconfirmat' in report
    assert page.evaluate('diagCalls')==0, page.evaluate('diagCalls')
    page.locator('#bidDiagOem').click()
    assert page.evaluate('diagCalls')==1 and not page.locator('#bidDiagPanel').is_visible()
    page.evaluate('window.BID.diagnostics=()=>"invalid json";window.BID.vehicleVoltageSnapshot=()=>JSON.stringify({available:true,volts:99});window.bidDiagOpen()')
    assert 'Inventar nativ: indisponibil' in page.locator('#bidDiagStatus').inner_text()
    assert 'Tensiune auto: indisponibilă' in page.locator('#bidDiagStatus').inner_text()
    page.locator('#bidDiagClose').click()
    assert page.locator('#bidSmartPanel').is_visible()
    print('PASS: BID Diagnostics missing/malformed bridge, OBD candidates, CAN inventory, valid/invalid voltage, OEM dispatch and return')
    page.get_by_role('button',name='Teme BID',exact=True).click()
    assert page.locator('#bidThemesPanel').is_visible()
    assert page.locator('#bidThemesOEM').is_disabled()
    page.locator('[data-bid-theme=black]').click()
    assert page.evaluate('localStorage.getItem("bid_clock_theme")')=='black'
    page.locator('#bidClockOpen').click()
    assert page.locator('#bidAnalogPanel').is_visible()
    assert not page.locator('#bidThemesPanel').is_visible()
    assert page.locator('#bidAnalogTicks line').count()==60
    old=page.locator('#bidSecondHand').get_attribute('transform')
    page.clock.run_for(2100)
    assert page.locator('#bidSecondHand').get_attribute('transform')!=old
    page.locator('#bidAnalogClose').click()
    assert page.locator('[data-bid-theme=black]').get_attribute('aria-pressed')=='true'
    page.locator('#bidThemesReset').click()
    assert page.evaluate('localStorage.getItem("bid_clock_theme")')=='burgundy'
    page.evaluate('window.themeCalls=0;window.BID.openQfThemes=()=>{window.themeCalls++};window.bidThemesOpen()')
    page.locator('#bidThemesOEM').click()
    assert page.evaluate('themeCalls')==1
    page.evaluate('window.bidThemesOpen()')
    page.locator('#bidThemesLegacy').click()
    assert page.locator('#overlay').is_visible()
    page.evaluate('window.bidThemesOpen()')
    page.locator('#bidThemesClose').click()
    assert page.locator('#bidSmartPanel').is_visible()
    assert not page.locator('#bidAnalogPanel').is_visible()
    print('PASS: BID Themes selection, persistence, live analog clock, reset, OEM dispatch, legacy and return')
    page.get_by_role('button',name='BID System',exact=True).click()
    assert page.locator('#bidSystemPanel').is_visible()
    page.locator('#bidSystemExport').click()
    backup=json.loads(page.locator('#bidSystemBackup').input_value())
    assert backup['format']=='DJ88-BID-preferences'
    page.locator('[data-favorite=waze]').click()
    assert page.locator('[data-launch-favorite=waze]').count()==0
    backup['preferences'].update(bid_clock_theme='champagne',bid_sound_profile='voice',bid_favorites=['maps','waze'])
    page.locator('#bidSystemBackup').fill(json.dumps(backup))
    page.locator('#bidSystemImport').click()
    assert 'restaurate' in page.locator('#bidSystemMessage').inner_text()
    assert page.locator('[data-launch-favorite=waze]').count()==1
    bad=json.loads(json.dumps(backup));bad['preferences']['bid_favorites']=['badCommand']
    page.locator('#bidSystemBackup').fill(json.dumps(bad))
    page.locator('#bidSystemImport').click()
    assert 'invalid' in page.locator('#bidSystemMessage').inner_text()
    assert page.evaluate('JSON.parse(localStorage.getItem("bid_favorites"))')==['maps','waze']
    page.evaluate('window.systemCalls=[];window.BID.open=x=>systemCalls.push(x);void 0')
    page.locator('[data-launch-favorite=waze]').click()
    assert page.evaluate('systemCalls.join(",")')=='waze', page.evaluate('systemCalls')
    page.evaluate('window.bidSystemOpen()')
    page.locator('#bidSystemOEM').click()
    assert page.evaluate('systemCalls.join(",")')=='waze,original'
    page.evaluate('window.bidThemesOpen()')
    assert page.locator('[data-bid-theme=champagne]').get_attribute('aria-pressed')=='true'
    page.evaluate('window.bidSoundOpen()')
    assert page.locator('[data-sound-profile=voice]').get_attribute('aria-pressed')=='true'
    page.evaluate('window.bidSystemOpen()')
    page.locator('#bidSystemClose').click()
    assert page.locator('#bidSmartPanel').is_visible()
    print('PASS: BID System backup, restore, invalid backup rejection, favorites, OEM dispatch, preference refresh, return')
    browser.close()
