(function(){'use strict';
const panel=document.getElementById('bidMotionPanel'),status=document.getElementById('bidWidgetStatus');
if(!panel)return;
let last='',lastSent=0;
const overlays=['drive','overlay','musicMenu','luxuryModal','diagnosticModal','bidDisplayPanel','bidDriveSettings','bidStudioEditor','bidStudioConfirm','bfShell','bfLive'];
function sync(){if(!window.BIDWidget)return;
const r=panel.getBoundingClientRect(),vw=document.documentElement.clientWidth,vh=document.documentElement.clientHeight;
const show=!document.hidden&&!overlays.some(id=>{const el=document.getElementById(id);return el&&el.classList.contains('on');})&&r.width>0&&r.height>0;
const moving=panel.dataset.moving==='true', valid=panel.dataset.available==='true';
const args=[r.x,r.y,r.width,r.height,vw,vh,show,!moving,valid];
const sig=JSON.stringify(args);if(sig===last&&Date.now()-lastSent<1500)return;last=sig;lastSent=Date.now();
try{BIDWidget.sync(...args);}catch(_){bidHealthRecord('bridge-sync');}
}
window.bidWidgetResync=function(){last='';sync();};
window.bidWidgetActivated=function(){window.bidWidgetResync();};
window.bidWidgetReveal=function(){if(window.bidDriveSettings)bidDriveSettings(false);window.bidWidgetResync();setTimeout(window.bidWidgetResync,300);};
window.bidWidgetSetupFailed=function(){if(window.bidDriveSettings)bidDriveSettings(true);window.bidWidgetResync();};
window.bidWidgetOpen=function(){sync();if(window.BIDWidget){try{BIDWidget.open();}catch(_){bidHealthRecord('bridge-open');if(status)status.textContent='Widget Android indisponibil';}}else if(status)status.textContent='Necesită aplicația Android';};
window.bidWidgetState=function(s){bidHealthWidgetState(s);if(!status||!s)return;status.textContent=s.configuring?'Configurare în curs':s.enabled?'Widget autorizat':Number(s.available)>0?s.available+' widget(uri) Google Maps disponibile':'Niciun widget Google Maps detectat';if(typeof s.detail==='string')status.textContent+=' · '+s.detail+(s.enabled?' · ID '+s.id:'')+(s.configuring?' · ID în așteptare '+s.pending:'');};
for(const id of overlays){const el=document.getElementById(id);if(el)new MutationObserver(sync).observe(el,{attributes:true,attributeFilter:['class']});}
new MutationObserver(sync).observe(panel,{attributes:true,attributeFilter:['data-moving','data-available','style']});
window.addEventListener('resize',sync);document.addEventListener('visibilitychange',sync);setInterval(sync,350);
sync();try{if(window.BIDWidget)BIDWidget.state();}catch(_){bidHealthRecord('bridge-state');}
})();
