(function(){'use strict';
const number=document.getElementById('bidSpeedNumber'),panel=document.getElementById('bidMotionPanel'),label=document.getElementById('bidMotionLabel'),canvas=document.getElementById('bidRoad');if(!number||!panel||!label||!canvas)return;
const ctx=canvas.getContext('2d');if(!ctx)return;const W=canvas.width,H=canvas.height;
const still=new Image(),frames=new Image();let last=0,speed=null,phase=0,raf=0,prev=0;
const reduced=window.matchMedia('(prefers-reduced-motion: reduce)');
function paint(){ctx.fillStyle='#160b12';ctx.fillRect(0,0,W,H);const i=Math.min(15,Math.floor(phase/12*16));if(frames.complete&&frames.naturalWidth===W*4&&frames.naturalHeight===H*4){ctx.drawImage(frames,i%4*W,Math.floor(i/4)*H,W,H,0,0,W,H);}else if(still.complete&&still.naturalWidth){ctx.drawImage(still,0,0,W,H);}label.textContent='Ilustrativ';}
function moving(){return speed!==null&&speed>=2&&last&&performance.now()-last<=4000&&!document.hidden&&!reduced.matches;}
function stop(){if(raf)cancelAnimationFrame(raf);raf=0;prev=0;}
function tick(ts){raf=0;if(!moving()){prev=0;return;}if(prev)phase=(phase+speed/3.6*Math.min(.1,(ts-prev)/1000))%12;prev=ts;paint();raf=requestAnimationFrame(tick);}
function unavailable(){last=0;speed=null;number.textContent='—';panel.dataset.available='false';panel.dataset.moving='false';stop();paint();number.title='GPS indisponibil';}
function accept(mps){if(typeof mps!=='number'||!Number.isFinite(mps)||mps<0||mps>100){unavailable();return;}speed=mps*3.6;last=performance.now();number.textContent=String(Math.round(speed));number.title='Viteză GPS';panel.dataset.available='true';panel.dataset.moving=String(speed>=2);paint();if(moving()){if(!raf)raf=requestAnimationFrame(tick);}else stop();}
window.bidGpsSpeedUpdate=accept;window.bidGpsSpeedUnavailable=unavailable;
setInterval(()=>{if(last&&performance.now()-last>4000)unavailable();},500);document.addEventListener('visibilitychange',()=>{if(document.hidden)unavailable();});
frames.onload=still.onload=paint;still.src='bid_drive_still.jpg';frames.src='bid_drive_photo_frames.jpg';unavailable();
})();