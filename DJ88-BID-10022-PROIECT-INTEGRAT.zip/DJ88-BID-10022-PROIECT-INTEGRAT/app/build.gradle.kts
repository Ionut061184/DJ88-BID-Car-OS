plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "ro.dj88bid.car"
    compileSdk = 35
    defaultConfig {
        manifestPlaceholders["bidGoogleMapsKey"] = System.getenv("BID_GOOGLE_MAPS_KEY")?.takeIf { it.isNotBlank() } ?: "BID_KEY_NOT_CONFIGURED"
        applicationId = "ro.dj88bid.car"
        minSdk = 23
        targetSdk = 28
        // GitHub Actions gives each build a monotonically increasing versionCode.
        // This does not solve Android's signing-certificate compatibility requirement.
        val ciBuild = System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull()
        versionCode = maxOf(10022, ciBuild?.let { 10000 + it } ?: 15)
        versionName = "1.6-oem-bridge-beta" + (ciBuild?.let { ".$it" } ?: "")
    }

    // The lab variant will never take over HOME. Themes candidate exposes an
    // OEM-shaped HOME component but cannot grant OEM signature or privileges.
    flavorDimensions += "activation"
    productFlavors {
        create("labSafe") {
            dimension = "activation"
            // Distinct app ID: installs beside any previous BID version, without uninstalling it.
            applicationIdSuffix = ".widgetlab"
            manifestPlaceholders["bidAppLabel"] = "DJ 88 BID WIDGET LAB"
            manifestPlaceholders["bidHomeEnabled"] = "false"
        }
        create("themesCandidate") {
            dimension = "activation"
            // Separate from past BID installations; must also match the QF001 lab config.
            applicationIdSuffix = ".qf001theme"
            manifestPlaceholders["bidAppLabel"] = "DJ 88 BID Luxury · QF001"
            manifestPlaceholders["bidHomeEnabled"] = "true"
        }
    }

    // Stable release signing is enabled only when GitHub Actions injects the secrets.
    // Never put private keystore bytes or passwords in the repository.
    val stableStore = System.getenv("BID_KEYSTORE_PATH")
    val stableAlias = System.getenv("BID_KEY_ALIAS")
    val stableStorePass = System.getenv("BID_KEYSTORE_PASSWORD")
    val stableKeyPass = System.getenv("BID_KEY_PASSWORD")
    if (!stableStore.isNullOrBlank() && !stableAlias.isNullOrBlank() &&
        !stableStorePass.isNullOrBlank() && !stableKeyPass.isNullOrBlank()) {
        signingConfigs {
            create("bidStable") {
                storeFile = file(stableStore)
                storePassword = stableStorePass
                keyAlias = stableAlias
                keyPassword = stableKeyPass
                enableV1Signing = true
                enableV2Signing = true
            }
        }
        buildTypes {
            getByName("release") {
                isMinifyEnabled = false
                signingConfig = signingConfigs.getByName("bidStable")
            }
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies { implementation("com.google.android.gms:play-services-maps:19.0.0") }
