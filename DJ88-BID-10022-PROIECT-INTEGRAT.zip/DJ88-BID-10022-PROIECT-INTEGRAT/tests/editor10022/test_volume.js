const assert=require('node:assert/strict');
function volumeDelta(start,now,scale){if(start.length!==2||now.length!==2||!Number.isFinite(scale)||scale<=0)return 0;const a=now.map((p,i)=>({x:(p.x-start[i].x)/scale,y:(p.y-start[i].y)/scale}));if(Math.abs(a[0].x)>35||Math.abs(a[1].x)>35||Math.abs(a[0].y-a[1].y)>35||a[0].y*a[1].y<=0)return 0;const y=(a[0].y+a[1].y)/2;return Math.abs(y)>=55?(y<0?1:-1):0;}
const a=[{x:0,y:100},{x:80,y:100}];
assert.equal(volumeDelta(a,[{x:0,y:30},{x:80,y:30}],1),1);
assert.equal(volumeDelta(a,[{x:0,y:170},{x:80,y:170}],1),-1);
assert.equal(volumeDelta(a,[{x:80,y:30},{x:160,y:30}],1),0);
assert.equal(volumeDelta(a,[{x:0,y:30},{x:80,y:170}],1),0);
assert.equal(volumeDelta(a,[{x:0,y:80},{x:80,y:80}],1),0);
assert.equal(volumeDelta(a,[{x:0,y:65},{x:80,y:65}],.5),1);
assert.equal(volumeDelta(a,[{x:0,y:30}],1),0);
assert.equal(volumeDelta(a,a,0),0);
console.log('8 tests passed');
