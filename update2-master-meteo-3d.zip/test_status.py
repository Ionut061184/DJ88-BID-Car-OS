from pathlib import Path
import json
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parent
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1280,'height':720})
    import base64
    assets=root/'assets'
    html=(assets/'index.html').read_text()
    css=(assets/'bid_status.css').read_text()
    html=html.replace('<link rel="stylesheet" href="bid_status.css">','<style>'+css+'</style>')
    for n in ('bid_approved.png','bid_fullbleed.png'):
        html=html.replace(n,'data:image/png;base64,'+base64.b64encode((assets/n).read_bytes()).decode())
    setup='Object.defineProperty(window,"localStorage",{value:{data:{},setItem(k,v){this.data[k]=v},getItem(k){return this.data[k]??null}}});window.testState={};window.testDisplay={};window.appliedModes=[];window.BID={displaySnapshot:()=>JSON.stringify(window.testDisplay),setDisplayMode:m=>window.appliedModes.push(m),connectivitySnapshot:()=>JSON.stringify(window.testState),batterySnapshot:()=>JSON.stringify({percent:100}),vehicleVoltageSnapshot:()=>JSON.stringify({available:true,volts:12.2})};'
    html=html.replace('</head>','<script>'+setup+'</script></head>')
    for n in ('bid_runtime.js','bid_status.js','bid_adaptive.js'):
        html=html.replace('<script src="'+n+'"></script>','<script>'+(assets/n).read_text()+'</script>')
    page.set_content(html)
    def resize(w,h):
        page.set_viewport_size({"width":w,"height":h})
        page.evaluate("() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)))")
    def status(state):
        page.evaluate('(s)=>{window.testState=s; document.dispatchEvent(new Event("visibilitychange"));}',state)
    def aria(id):return page.locator('#'+id).get_attribute('aria-label')
    status({'bluetooth':False,'wifi':False,'simPresent':False})
    assert aria('bidBtText')=='Bluetooth: oprit'
    assert aria('bidWifiText').startswith('Wi-Fi: oprit')
    assert aria('bidCellText')=='SIM absent'
    status({'bluetooth':True,'bluetoothConnected':False,'wifi':True,'wifiConnected':False,'simPresent':True,'cellLevel':0,'networkGeneration':'2G'})
    assert 'neconectat' in aria('bidBtText') and 'neconectat' in aria('bidWifiText')
    assert '2G' in aria('bidCellText') and '0/4' in aria('bidCellText')
    status({'bluetooth':True,'bluetoothConnected':True,'wifi':True,'wifiConnected':True,'wifiLevel':2,'wifiRx':True,'wifiTx':False,'simPresent':True,'cellLevel':3,'networkGeneration':'4G+'})
    assert aria('bidBtText')=='Bluetooth: conectat'
    assert '2/4' in aria('bidWifiText') and 'trafic activ' in aria('bidWifiText')
    assert '4G+' in aria('bidCellText') and '3/4' in aria('bidCellText')
    assert page.locator('#bidCellText rect[fill="#f6d69c"]').count()==3
    assert page.locator('#bidVoltageText').inner_text()=='12.2 V'
    assert '100%' in page.locator('#bidBatteryText').inner_text()
    page.evaluate('window.updateGpsWeather({city:"Robăneștii de Sus – localitate cu denumire lungă",temperature:6,code:3,fresh:true,note:"Vreme după GPS"})')
    assert page.locator('#bidWeatherText').inner_text().startswith('6° · Robăneștii')
    for w,h in [(1280,720),(1856,821)]:
        resize(w,h)
        band=page.locator('#bidStatusLive').bounding_box()
        assert band and band['width']>0
        for id in ['bidWeatherText','bidBtText','bidCellText','bidWifiText','bidBatteryText','bidVoltageText']:
            b=page.locator('#'+id).bounding_box()
            assert b['x']>=band['x']-0.1 and b['x']+b['width']<=band['x']+band['width']+0.1,(w,id,b,band)
    resize(1280,720)
    page.evaluate('window.updateGpsWeather({city:"Robăneștii de Sus",temperature:6,code:3,fresh:false,note:"Date meteo neactualizate"})')
    assert page.locator('#bidWeatherText').inner_text().startswith('* 6°')
    status({})
    assert 'indisponibil' in aria('bidBtText') and 'necunoscută' in aria('bidCellText')
    status({'simPresent':True,'networkGeneration':'6G','cellLevel':4,'wifi':True,'wifiConnected':True,'wifiLevel':4,'bluetooth':True,'bluetoothConnected':True})
    assert '6G' in aria('bidCellText') # renderer only, not hardware support
    # Weather conditions and day/night are driven only by the provider.
    for code,day,name in [(0,True,'Senin'),(0,False,'Senin'),(2,True,'Parțial noros'),(3,True,'Noros'),(45,True,'Ceață'),(61,True,'Ploaie'),(73,True,'Ninsoare'),(95,True,'Furtună')]:
        page.evaluate('(d)=>window.updateGpsWeather(d)',{'city':'Robăneștii de Sus','temperature':6,'code':code,'isDay':day,'fresh':True})
        assert aria('bidWeatherIcon')==name
        assert page.locator('#bidWeatherIcon img').count()==1
        assert page.locator('#bidWeatherIcon img').evaluate('(img)=>img.src.startsWith("data:image/png;base64,")')
    page.evaluate('window.updateGpsWeather({code:0,isDay:false,fresh:false})')
    assert 'neactualizat' in aria('bidWeatherIcon')
    def display(lux,expected):
        page.evaluate('(lux)=>{window.testDisplay={lux};window.bidDisplayMode("auto")}',lux)
        assert page.evaluate('window.appliedModes.at(-1)')==expected
    display(14000,'sun');display(9000,'sun');display(400,'day');display(12,'night');display(35,'night');display(90,'day');display(None,'system')
    page.evaluate('window.updateGpsWeather({code:0,isDay:false,fresh:true})')
    assert page.evaluate('window.appliedModes.at(-1)')=='night'
    page.evaluate('window.updateGpsWeather({code:0,isDay:true,fresh:true})')
    assert page.evaluate('window.appliedModes.at(-1)')=='day'
    page.evaluate('window.bidDisplayOpen(true)')
    page.locator('[data-bid-display=sun]').click()
    assert page.evaluate('window.appliedModes.at(-1)')=='sun'
    assert page.evaluate('localStorage.getItem("bid_display_mode")')=='sun'
    page.evaluate('closeAll()')
    assert not page.locator('#bidDisplayPanel').is_visible()
    for w,h in [(1280,720),(1856,821)]:
        resize(w,h)
        icon=page.locator('#bidWeatherIcon').bounding_box();band=page.locator('#bidStatusLive').bounding_box()
        assert icon['x']+icon['width']<=band['x']+0.1
        assert icon["y"]>=band["y"]-0.1 and icon["y"]+icon["height"]<=band["y"]+band["height"]+0.1,(icon,band)
    print('PASS: 7 original scenarios + 8 weather states, stale state, 7 sensor transitions, 2 GPS daylight fallbacks, display setting persistence and two viewport bounds')
    browser.close()
