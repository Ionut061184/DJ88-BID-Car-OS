BID Update 2 — integrare MASTER, fără animație la pornire.
Resurse testate în Chromium cu bridge nativ simulat. PNG-urile și toate zonele tactile sunt identice cu APK-ul Contur Liber.
Acest ZIP nu este APK. Se încarcă în rădăcina ramurii feature/bid-adaptive-gps-status, sub numele update2-master.zip. Workflow-ul Update 2 verifică hash-ul ZIP și imaginile, rulează testele și compilează separat.
Modul Wi-Fi trafic real și Bluetooth/modem OEM rămân de verificat; volum audio separat și backup încă neimplementate. Nu se modifică firmware-ul. APK-ul din mașină rămâne rezervă.

Miniaturi meteo PNG cu umbrire 3D, 84×76, afișate 40×36; integrate local în JS.
